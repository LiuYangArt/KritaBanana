from .krita_banana import KritaBananaExtension

# Krita Banana by LiuYang
