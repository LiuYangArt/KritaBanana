# Krita 中调用Google nano banana pro生图的插件

- 第三方api
- 支持文生图/图生图模式
- prompt 预设管理
<img width="587" height="658" alt="image" src="https://github.com/user-attachments/assets/b3674e46-177d-4290-ba43-bee5662fcbee" />


## 插件下载
[https://github.com/LiuYangArt/KritaBanana/blob/main/Plugin/KritaBanana.zip](https://github.com/LiuYangArt/KritaBanana/blob/main/Plugin/KritaBanana.zip)

## 插件安装
- 在菜单选择
<img width="565" height="353" alt="image" src="https://github.com/user-attachments/assets/093d8a6e-ffc6-4d52-99bc-4f50fb6fa03d" />
- 或手动复制
<img width="1155" height="920" alt="image" src="https://github.com/user-attachments/assets/8e16f164-7041-43d8-aae0-318b513a0835" />

- 在设置中启用，然后重启krita
<img width="1175" height="926" alt="image" src="https://github.com/user-attachments/assets/7ac3c0a8-1374-4d52-8621-95b3b316e3d9" />

- Settings>Dockers>KritaBanana
<img width="796" height="785" alt="image" src="https://github.com/user-attachments/assets/b0fd282e-e3db-4d99-bccd-5e7fc67f8460" />

- 需自行购买api
- 在Settings页面填入API。目前只在yunwu/gptgod/openrouter测试过，google 官方的API我这边没有条件测。openrouter对ip也有限制。
  [yunwu](https://yunwu.ai/register?aff=VE3i) | [gptgod](https://gptgod.site/#/register?invite_code=5ax35dxlk4bys0j7jnzqypwkc)
